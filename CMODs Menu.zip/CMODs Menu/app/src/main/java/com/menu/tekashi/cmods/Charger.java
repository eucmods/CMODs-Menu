package com.menu.tekashi.cmods;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import android.view.View.OnLongClickListener;
import android.view.LayoutInflater;
import android.widget.Switch;
import android.graphics.drawable.GradientDrawable;
import android.app.AlertDialog;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.text.Html;
import android.graphics.PorterDuff;
import java.io.InputStream;
import android.graphics.drawable.Drawable;
import android.content.pm.PackageInstaller;
import android.os.Messenger;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.content.ServiceConnection;
import android.content.ComponentName;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.animation.TimeAnimator;
import android.graphics.Shader;
import android.graphics.LinearGradient;
import android.graphics.drawable.AnimationDrawable;
import android.annotation.TargetApi;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.content.res.AssetManager;
import android.transition.Visibility;
import android.graphics.Canvas;
import android.graphics.Point;
import android.os.Process;
import android.view.WindowManager.LayoutParams;
import android.app.ActivityManager;
import android.view.ViewGroup;
import java.io.RandomAccessFile;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import java.time.temporal.ValueRange;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
//import com.topjohnwu.superuser.Shell;

public class Charger extends Service {

	private static RandomAccessFile raf;

    private  WindowManager janela_menu;
	
	private  ImageView DevTeam;

	private  FrameLayout Cmods_Frames;

	private  RelativeLayout collapseView;

	private  LinearLayout CoRingaModz_YT,Dev_cmods,BUTÃO_LAYOUT;//All Linear Layout
	
	int cm_ods;
	
	private  LinearLayout Borda_do_Titulo;

	private  LinearLayout relativeLayout;

	private  GradientDrawable gd = new GradientDrawable();
	private  GradientDrawable anim_btn_close = new GradientDrawable();
	private  ValueAnimator animator;
	private  ValueAnimator animator_c;

	private static String TAG = "Mod By CoRingaModz";
	public String daemonPath;
	
	/*
	void Inject(){
		daemonPath = getFilesDir().toString() + "/google";
		if (Shell.rootAccess()) {
			Shell.su("chmod 777 " + daemonPath).exec();
			Shell.su(daemonPath).submit();
			Toast.makeText(this, "Sucess Lib [INJECT] ao iniciar", Toast.LENGTH_SHORT).show();
		}
	}
	*/
	public void Inject_Lib2(String origPath, String targetPath) {
        cmods_exec("cp " + origPath + " " + targetPath);
    }
    private  void TEKASHI_TEAM(){
		Cmods_Frames = new FrameLayout(this);
        FrameLayout.LayoutParams fraLayoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        Cmods_Frames.setLayoutParams(fraLayoutParams);

        RelativeLayout Subs_Relative = new RelativeLayout(this);
        RelativeLayout.LayoutParams relative_Sub = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        Subs_Relative.setLayoutParams(relative_Sub);
        
		collapseView = new RelativeLayout(this);
        collapseView.setLayoutParams(relative_Sub);
		
		DevTeam = new ImageView(this);
		//DevTeam.setImageDrawable(this.getResources().getDrawable(R.drawable.aim_on));
		LinearLayout.LayoutParams CMODSDEV = new LinearLayout.LayoutParams(dp(69), dp(69));
        DevTeam.setLayoutParams(CMODSDEV);
		try {InputStream open = this.getAssets().open("cmIcon.png");
		DevTeam.setImageDrawable(Drawable.createFromStream(open, null));
		open.close();}catch(IOException ex){return;}
		collapseView.addView(DevTeam);
		
		Dev_cmods = new LinearLayout(this);
		Dev_cmods.setVisibility(View.GONE);
		Dev_cmods.setAlpha(0.8f);
		Dev_cmods.setGravity(17);
        Dev_cmods.setOrientation(LinearLayout.VERTICAL);
		Dev_cmods.setLayoutParams(new LinearLayout.LayoutParams(dp(292), dp(338)));
	
		relativeLayout = new LinearLayout(this);
        relativeLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        relativeLayout.setPadding(10, 10, 10, 10);
        relativeLayout.setGravity(1);
		relativeLayout.setOrientation(LinearLayout.HORIZONTAL);
		relativeLayout.setBackground(anim_btn_close);
	
		ImageView close_menu = new ImageView(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(95), dp(95));
		layoutParams.gravity = 17;
		try {InputStream openx = this.getAssets().open("close.png");
        close_menu.setImageDrawable(Drawable.createFromStream(openx, null));
        openx.close();}catch(IOException ex){return;}
		close_menu.setLayoutParams(layoutParams);
		relativeLayout.addView(close_menu);
		close_menu.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
					collapseView.setVisibility(View.VISIBLE);
					Dev_cmods.setVisibility(View.GONE);
                }
            });
		LinearLayout Layout_Principal = new LinearLayout(this);
        LinearLayout.LayoutParams layout_LinearLayout_Principal = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(238));
        Layout_Principal.setLayoutParams(layout_LinearLayout_Principal);
        Layout_Principal.setOrientation(LinearLayout.VERTICAL);
		Layout_Principal.setBackgroundColor(Color.parseColor("#ff000000"));///TESTA
	
		ScrollView deslizamento = new ScrollView(this);
        LinearLayout.LayoutParams scrollView_Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(238));//220
        deslizamento.setLayoutParams(scrollView_Params);
		
		Borda_do_Titulo = new LinearLayout(this);
        Borda_do_Titulo.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));
		Borda_do_Titulo.setGravity(1);
		Borda_do_Titulo.setBackground(gd);
	
		final TextView Titulo_do_Menu = new TextView(this);
		LinearLayout.LayoutParams layoutParamsxx = new LinearLayout.LayoutParams(-2, dp(300));
		Titulo_do_Menu.setLayoutParams(layoutParamsxx);
        Titulo_do_Menu.setText("CMODs Menu");
        Titulo_do_Menu.setTextColor(Color.parseColor("WHITE"));
        Titulo_do_Menu.setTypeface(Typeface.DEFAULT_BOLD);
        Titulo_do_Menu.setTextSize(22.0f);
		Typeface typeface = Typeface.createFromAsset(this.getAssets(), "fonts/air.ttf");
		Titulo_do_Menu.setTypeface(typeface, Typeface.BOLD);
		Titulo_do_Menu.setPadding(10, 10, 10, 15);
		Borda_do_Titulo.addView(Titulo_do_Menu);
		
		LinearLayout borda_1 = new LinearLayout(this);
        borda_1.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(3)));
        borda_1.setBackgroundColor(Color.parseColor("WHITE"));
		borda_1.setPadding(0, 0, 0, 10);
		
		CoRingaModz_YT = new LinearLayout(this);
		CoRingaModz_YT.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, -1));
        CoRingaModz_YT.setOrientation(LinearLayout.VERTICAL);
        
		LinearLayout borda_2 = new LinearLayout(this);
		borda_2.setLayoutParams(new LinearLayout.LayoutParams(-1, 3));
        borda_2.setBackgroundColor(Color.parseColor("WHITE"));
        borda_2.setPadding(0, 0, 0, 10);
		
		BUTÃO_LAYOUT = new LinearLayout(this);
        BUTÃO_LAYOUT.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, -1));
        BUTÃO_LAYOUT.setOrientation(LinearLayout.VERTICAL);
		
		CoRingaModz_YT.addView(BUTÃO_LAYOUT);
		
		Dev_cmods.addView(Borda_do_Titulo);
		
		Dev_cmods.addView(borda_1);
		
		deslizamento.addView(CoRingaModz_YT);
		
		Layout_Principal.addView(deslizamento);
		
		Dev_cmods.addView(Layout_Principal);
		
		Dev_cmods.addView(borda_2);
		
		Subs_Relative.addView(collapseView);
		
		Dev_cmods.addView(relativeLayout);
		
		Subs_Relative.addView(Dev_cmods);
        Cmods_Frames.addView(Subs_Relative);
		MrEzCheatsYT();
		cmC_Start();
		cmC_Start_close();
		int flag;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1){
            flag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }else {
            flag = WindowManager.LayoutParams.TYPE_PHONE;
        }
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,flag, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 100;
        janela_menu = (WindowManager) this.getSystemService(Context.WINDOW_SERVICE);
        janela_menu.addView(Cmods_Frames, params);
		Cmods_Frames.setOnTouchListener(new View.OnTouchListener() {
				private int initialX;
				private int initialY;
				private float initialTouchX;
				private float initialTouchY;
				boolean isLongClick = false;
				Handler handler_longClick = new Handler();
				Runnable runnable_longClick = new Runnable() {
					@Override public void run() {
						isLongClick = true;
						Close_segurar();
					}
				};
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							handler_longClick.postDelayed(runnable_longClick, 2000);
							return true;
						case MotionEvent.ACTION_UP:
							int Xdiff = (int) (event.getRawX() - initialTouchX);
							int Ydiff = (int) (event.getRawY() - initialTouchY);
							handler_longClick.removeCallbacks(runnable_longClick);
							if (Xdiff < 10 && Ydiff < 10) {
								if (VerColapso()) {
									collapseView.setVisibility(View.GONE);
									Dev_cmods.setVisibility(View.VISIBLE);
								}
							}
							return true;
						case MotionEvent.ACTION_MOVE:
							params.x = initialX + (int) (event.getRawX() - initialTouchX);
							params.y = initialY + (int) (event.getRawY() - initialTouchY);
							janela_menu.updateViewLayout(Cmods_Frames, params);
							return true;
					}
					return false;
				}
		});
	}///WORK ANIMATION
	public  void cmC_Start() {
        final int start = Color.parseColor("#ffff1432");
        final int end = Color.parseColor("#ff00e2ff");
        final ArgbEvaluator evaluator = new ArgbEvaluator();
        gd.setCornerRadius(0f);
		gd.setCornerRadii(new float[] { 9, 9, 9, 9, 0, 0, 0, 0 });
        gd.setOrientation(GradientDrawable.Orientation.TL_BR);
        final GradientDrawable gradient = gd;
        animator = TimeAnimator.ofFloat(0.0f, 1.0f);
        animator.setDuration(3000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					Float fraction = valueAnimator.getAnimatedFraction();
					int newStrat = (int) evaluator.evaluate(fraction, start, end);
					int newEnd = (int) evaluator.evaluate(fraction, end, start);
					int[] newArray = {newStrat, newEnd};
					gradient.setColors(newArray);
				}
			});
        animator.start();
    }
	public  void cmC_Start_close() {
        final int start_c = Color.parseColor("#ffff1432");
        final int end_c = Color.parseColor("#ff00e2ff");
        final ArgbEvaluator evaluator_c = new ArgbEvaluator();
        anim_btn_close.setCornerRadius(0f);
		anim_btn_close.setCornerRadii(new float[] { 0, 0, 0, 0, 9, 9, 9, 9 });
        anim_btn_close.setOrientation(GradientDrawable.Orientation.TL_BR);
        final GradientDrawable gradient_c = anim_btn_close;
        animator_c = TimeAnimator.ofFloat(0.0f, 1.0f);
        animator_c.setDuration(3000);
        animator_c.setRepeatCount(ValueAnimator.INFINITE);
        animator_c.setRepeatMode(ValueAnimator.REVERSE);
        animator_c.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					Float fraction_c = valueAnimator.getAnimatedFraction();
					int newStrat_c = (int) evaluator_c.evaluate(fraction_c, start_c, end_c);
					int newEnd_c = (int) evaluator_c.evaluate(fraction_c, end_c, start_c);
					int[] newArray_c = {newStrat_c, newEnd_c};
					gradient_c.setColors(newArray_c);
				}
			});
        animator_c.start();
    }
	private  void MrEzCheatsYT(){
		addSwitch("Aim Head Reg", new SW() {
				public void OnWrite(boolean isChecked) {
					if (isChecked) {
						//MemoryCheat(cmods,200);
					}
				}
			});
	
		addSwitch("Wall Stone", new SW() {
				public void OnWrite(boolean isChecked) {
					if (isChecked) {
						//MemoryCheat(cmods,022);
					} else {
						//MemoryCheat(cmods,000);
					}
				}
			});
	
		}
		private void addSwitch(String name, final SW listner) {
        CheckBox sw = new CheckBox(this);
        sw.setText(name);
        sw.setTextColor(Color.WHITE);
		sw.setPadding(10, 3, 3, 3);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					listner.OnWrite(isChecked);
				}
			});
		View line1 = new View(this);
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(MATCH_PARENT, dp(3));
        line1.setLayoutParams(lineParams);
		line1.setBackgroundColor(Color.WHITE);
        this.BUTÃO_LAYOUT.addView(sw);
		this.BUTÃO_LAYOUT.addView(line1);
    }
	public static void DeletedCMODs(String remv) {
        cmods_exec("rm -rf " + remv);
    }
	public static String CMODs_exec(String cmd) {
        String result = "";
        DataOutputStream dos = null;
        DataInputStream dis = null;
        try {
            java.lang.Process p = Runtime.getRuntime().exec("su");
            dos = new DataOutputStream(p.getOutputStream());
            dis = new DataInputStream(p.getInputStream());
            Log.i(TAG, cmd);
            dos.writeBytes(cmd + "\n");
            dos.flush();
            dos.writeBytes("exit\n");
            dos.flush();
            String line = null;
            while ((line = dis.readLine()) != null) {
                Log.d("result", line);
                result = result + line + "\n";
            }
            p.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (dos != null) {
                try {
                    dos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (dis != null) {
                try {
                    dis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }
	
	public static int cmods_exec(String cmd) {
        int result = -1;
        DataOutputStream dos = null;

        try {
            java.lang.Process p = Runtime.getRuntime().exec("su");
            dos = new DataOutputStream(p.getOutputStream());

            Log.i(TAG, cmd);
            dos.writeBytes(cmd + "\n");
            dos.flush();
            dos.writeBytes("exit\n");
            dos.flush();
            p.waitFor();
            result = p.exitValue();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (dos != null) {
                try {
                    dos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }
	@Override
    public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(rootIntent);
    }
    private void Thread() {
        if (this.Cmods_Frames == null) {
            return;
        }
    }
	private  boolean VerColapso() {
		return Cmods_Frames == null || Cmods_Frames.getVisibility() == View.VISIBLE;
    }
	public void Destroy() {
        super.onDestroy();
        if (Cmods_Frames != null) {
            janela_menu.removeView(Cmods_Frames);
            Cmods_Frames = null;
		}
    }
	private  void Close_segurar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            cm_ods = 2038;
        } else {
            cm_ods = 2002;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this, 5);
		builder.setTitle("CMODs Developer");
		builder.setMessage("Tem certeza de que deseja interromper o Regedit?\nVocê não poderá acessar o Regedit novamente até reabrir o Jogo!");
		builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					DevTeam.setVisibility(View.GONE);
					Dev_cmods.setVisibility(View.GONE);
					collapseView.setVisibility(View.GONE);
					showMessage("Closing...");
				}
			});
		builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});

		AlertDialog dialog = builder.create();
		dialog.getWindow().setType(cm_ods);
		dialog.show();
	}
	@Override
    public void onCreate() {
        super.onCreate();
      //  Inject();
		TEKASHI_TEAM();
		final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    Charger.this.Thread();
                    handler.postDelayed(this, 1000);
                }
            });
		}
	public  void showMessage(String txt){
		Toast.makeText(this, txt, Toast.LENGTH_LONG).show();
	}
	@Override
    public IBinder onBind(Intent intent) {
        return null;
    }
	private interface Btn_CM {
        public void OnWrite();
    }
	private  interface SW {
        void OnWrite(boolean z);
    }
    private  int dp(int value){
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, this.getResources().getDisplayMetrics());
    }
}
