package com.menu.tekashi.cmods;
 
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.os.Build;
import android.view.View;
import android.provider.Settings;
import android.net.Uri;
import android.os.Handler;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;
import android.provider.Settings;
import android.net.Uri;
import android.widget.Toast;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import android.util.Log;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.FileOutputStream;

public class MainActivity extends Activity { 

	public static boolean Activated = false;
	private static String TAG = "Mod By CoRinga Modz";
	private static boolean mHaveRoot;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		haveRoot();
    }
	public void inject(View v){
		Start(this);
	}
	public static void Start(final Context context) {
        //Check if overlay permission is enabled or not
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
											 Uri.parse("package:" + context.getPackageName())));
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
					@Override
					public void run() {
						System.exit(1);
					}
				}, 10000);
            return;
        } else {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
					@Override
					public void run() {
						StartLib(context);
						context.startService(new Intent(context, Charger.class));
						Intent GAMEFREEFIRE = context.getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
						context.startActivity(GAMEFREEFIRE);
						}
				}, 1000);
        }
    }
	private static void StartLib(final Context ctx) {
		String filesDir = ctx.getFilesDir().toString() + "/google";
		try {
			OutputStream myOutput = new FileOutputStream(filesDir);
			byte[] buffer = new byte[1024];
			int length;
			InputStream myInput = ctx.getAssets().open("google");
			while ((length = myInput.read(buffer)) > 0) {
				myOutput.write(buffer, 0, length);
			}
			myInput.close();
			myOutput.flush();
			myOutput.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public boolean haveRoot() {
        if (!mHaveRoot) {
            int ret = Charger.cmods_exec("echo test");
            if (ret != -1) {
                Log.i(TAG, "have root!");
                mHaveRoot = true;
            } else {
                Log.i(TAG, "not root!");
            }
        } else {
            Log.i(TAG, "mHaveRoot = true, have root!");
        }
        return mHaveRoot;
    }
}
